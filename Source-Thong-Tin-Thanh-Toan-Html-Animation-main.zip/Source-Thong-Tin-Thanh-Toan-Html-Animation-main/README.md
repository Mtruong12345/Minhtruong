<h4>Demo Image: </h4>
<img
  src="https://i.imgur.com/jWSC7ie.png"
  alt="Alt text"
  title="Optional title"
  style="display: inline-block; margin: 0 auto; max-width: 300px">
